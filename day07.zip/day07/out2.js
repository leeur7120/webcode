function f3() {
    alert("함수 3번을 사용(호출)하였습니다.")
}
function f4() {
    alert("함수 4번을 사용(호출)하였습니다.")
}