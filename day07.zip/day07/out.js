function f1() {
    alert("함수 1을 사용(호출)하였습니다.")
}
function f2() {
    alert("함수 2를 사용(호출)하였습니다")
}