function go() {
    alert("go함수를 누르셨군요.")
}
function move() {
    alert("move함수를 누르셨군요")
}